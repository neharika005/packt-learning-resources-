## Using OSForensics to find hidden material


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of evidence collection is.

Explain why using the OSForensics tool for both Windows and Linux should be a
part of the evidence collection steps taken by the IH&R team.

Identify how to install and use the OSFornesics tool.


### External Resources:

Using OSForensics to find hidden material

OSForensics download link:
https://www.osforensics.com/download.html
