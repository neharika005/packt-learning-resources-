## Using Suricata IDS


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of collecting and analyzing information by using the
Suricata IDS tool entails.

Explain why using the Suricata IDS tool should be a part of the collecting and
analyzing information steps taken by the IH&R team.

Identify how to install and use the Suricata IDS tool.


### External Resources:

Using Suricata IDS

Download link for the Suricata IDS tool:
https://suricata-ids.org/download/
