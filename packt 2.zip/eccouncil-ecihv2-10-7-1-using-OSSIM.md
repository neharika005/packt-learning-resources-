## Using OSSIM


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of collecting and analyzing information by using the
OSSIM tool entails.

Explain why using the OSSIM tool should be a part of the proactive collecting
and analyzing information steps taken by the IH&R team.

Identify how to install and use the OSSIM tool.


### External Resources:

Using OSSIM

Download link for the OSSIM tool:
https://cybersecurity.att.com/products/ossim?
