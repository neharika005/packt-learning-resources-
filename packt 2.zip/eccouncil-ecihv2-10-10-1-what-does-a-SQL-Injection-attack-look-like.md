## What does a SQL Injection Attack look like?


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of a SQL Injection attack is.

Explain why SQL Injection attacks provide so many opportunities for bad actors to
access confidential data from a targeted system.

Identify why and how IH&R team members should proactively ensure that systems
are defended against SQL Injection attacks.


### External Resources:

What does a SQL Injection Attack look like?
