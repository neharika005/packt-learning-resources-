## What does a XSS Attack look like?


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of a XSS attack is.

Explain why XSS attacks provide so many opportunities for bad actors to take
over a targeted system.

Identify why and how IH&R team members should proactively ensure that web sites
are defended against XSS attacks.


### External Resources:

What does a XSS Attack look like?
