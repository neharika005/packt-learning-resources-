## Collecting information by tracing emails


### Objectives:

At the end of this episode, I will be able to:

Understand what the concept of collecting information by tracing emails is.

Explain why using the eMailTrackerPro tool for should be a part of the
collecting information by tracing emails steps taken by the IH&R team.

Identify how to install and use the eMailTrackerPro tool.


### External Resources:

Collecting information by tracing emails

Download link for the eMailTrackerPro tool:
http://www.emailtrackerpro.com/download.html
